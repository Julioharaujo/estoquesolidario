package br.com.estoquesolidario.EstoqueSolidario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueSolidarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstoqueSolidarioApplication.class, args);
	}

}
